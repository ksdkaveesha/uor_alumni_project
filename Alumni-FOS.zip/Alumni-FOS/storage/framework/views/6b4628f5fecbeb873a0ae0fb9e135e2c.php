<!DOCTYPE html>
<html>
<head>
    <title>Alumni-FOS Register Acceptence</title>
</head>

<body>

    <p style="font-size: 12px">
        Dear <?php echo e($user); ?>,<br>
        You have successfully registered to the Alumni-FOS.<br>
        Thank you. Best Regards!
    </p><br>

    <p><?php echo "Please Don't reply to this email"; ?></p>

</body>

</html><?php /**PATH D:\Github\uor_alumni_project\Alumni-FOS\resources\views/email/RegisterMail.blade.php ENDPATH**/ ?>