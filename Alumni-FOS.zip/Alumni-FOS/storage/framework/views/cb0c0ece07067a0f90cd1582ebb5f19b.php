<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Update Profile</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
  <!--Bootstrap CDN-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <!-- Template Main CSS File -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/user.css')); ?>">

  <!-- =======================================================
  * Template Name: iPortfolio
  * Updated: Jan 29 2024 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->


  <!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="css/util.css">
        <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->


    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Register Form</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>


  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>
    <div style="position: absolute">

        <img src="images/logo.png">
    </div>



  <!-- ======= Header ======= -->
  <header id="header">

    <div class="d-flex flex-column">
        <div class="profile2">
            <img src="images/logo.png">
        </div>
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
      <div class="profile">
        <img src="assets/img/profile-img.jpg" alt="" class="img-fluid rounded-circle">
        <h4 style="text-align: center" class="text-light"><?php echo e(auth()->guard('webadmin')->user()->name); ?></h4>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
          <li><a href="#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a></li>
          <li><a href="/admin2" class="nav-link scrollto"><i class="bx bx-edit"></i> <span>User privileges</span></a></li>
          <li><a href="/admin3" class="nav-link scrollto"><i class="bx bx-edit"></i> <span>Admin privileges</span></a></li>
          <form id="logoutForm" method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <!-- Logout button or link -->
            <li>
              <a href="#" class="nav-link scrollto" onclick="showLogoutModal()">
                  <i class="bx bx-log-out"></i>
                  <span
                      style="background:none;border:none;padding:0;color: #6f7180; cursor:pointer;">Logout</span>
              </a>
          </li>
        </form>


        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->


  <!-- Logout Confirmation Modal -->
  <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="staticBackdropLabel">Logout Confirmation</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to logout?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" onclick="logout()">Logout</button>
        </div>
      </div>
    </div>
  </div>


  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center" style="background-image: <?php echo e(asset('assets/img/profile-img.jpg')); ?>">
    <div class="hero-container" data-aos="fade-in">

      <h1>Hi <?php echo e(auth()->guard('webadmin')->user()->name); ?></h1>
      <p>Welcome to <span class="typed" data-typed-items="University of Ruhuna, Faculty of Science"></span></p>
    </div>
  </section>
  <!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
          <!--<p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>-->
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="assets/img/profile-img.jpg" class="img-fluid" alt="">
            <!--<br><br>
            <h3 style="text-align: center"><b> <?php echo e(auth()->guard('webadmin')->user()->name); ?> </b></h3>-->
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3><?php echo e(auth()->guard('webadmin')->user()->name."'s Profile"); ?></h3>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Name:</strong> <span><?php echo e(auth()->guard('webadmin')->user()->name); ?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span><?php echo e(auth()->guard('webadmin')->user()->email); ?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Phone No:</strong> <span>+<?php echo e(auth()->guard('webadmin')->user()->m_code); ?>-<?php echo e(auth()->guard('webadmin')->user()->mobile); ?></span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- End About Section -->

    <!-- ======= Update Section =======
    <section id="update" class="contact">
        <div class="container">

          <div class="section-title">
            <h2>Update Profile</h2>
          </div>

          <div class="row" data-aos="fade-in">

            <div class="col-lg-5 d-flex align-items-stretch">
                <form action="forms/contact.php" method="post" role="form" class="php-email-form">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-12" data-aos="fade-right">
                        <div>
                            <img src="https://media.licdn.com/mpr/mpr/shrinknp_200_200/AAEAAQAAAAAAAAgvAAAAJDMzMWI1NzdiLTg1NjAtNGZhNS04MWRlLTRmNjY2NDY0M2Y3Zg.jpg" class="expert-img">
                        </div>
                          <div class="upload-button"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></div>
                            <input class="file-upload" type="file" accept="image/*"></input>
                        <script>
                                    $(function(){
                                        $('.file-upload').change( function(e) {

                                            var img = URL.createObjectURL(e.target.files[0]);
                                            $('.expert-img').attr('src', img);
                                        });
                                        $(".upload-button").on('click', function() {
                                                    $(".file-upload").click();
                                                    });
                                    });
                        </script>


                    </div>
                    <br>
                    <div class="text-center"><button type="submit">Add photo</button></div>
                </form>
            </div>

            <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
              <form action="<?=url('/update')?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="address"><h4><b>Personal Details</b></h4></label>
                </div>
                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e(auth()->guard('webadmin')->user()->name); ?>">
                </div>
                <div class="form-group">
                    <label for="id_num">ID Number</label>
                    <input type="text" class="form-control" name="id_num" id="id_num" value="<?php echo e(auth()->guard('webadmin')->user()->id_num); ?>">
                </div>
                <div class="row">
                  <div class="form-group col-md-6">
                    <label for="graduation_year">Year of Graduation</label>
                    <input type="text" name="graduation_year" class="form-control" id="graduation_year" value="<?php echo e(auth()->guard('webadmin')->user()->graduation_year); ?>">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="mobile">Phone Number</label>
                    <input type="text" class="form-control" name="mobile" id="mobile" value="<?php echo e(auth()->guard('webadmin')->user()->mobile); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="country">Country</label>
                  <select class="form-control" name="country" id="country" value="<?php echo e(auth()->guard('webadmin')->user()->country); ?>">
                    <option value="" disabled selected>Select Country</option>
                    <option value="Afghanistan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Afghanistan' ? 'selected' : ''); ?>>Afghanistan</option>
                    <option value="Åland Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Åland Islands' ? 'selected' : ''); ?>>Åland Islands</option>
                    <option value="Albania" <?php echo e(auth()->guard('webadmin')->user()->country === 'Albania' ? 'selected' : ''); ?>>Albania</option>
                    <option value="Algeria" <?php echo e(auth()->guard('webadmin')->user()->country === 'Algeria' ? 'selected' : ''); ?>>Algeria</option>
                    <option value="American Samoa" <?php echo e(auth()->guard('webadmin')->user()->country === 'American Samoa' ? 'selected' : ''); ?>>American Samoa</option>
                    <option value="Andorra" <?php echo e(auth()->guard('webadmin')->user()->country === 'Andorra' ? 'selected' : ''); ?>>Andorra</option>
                    <option value="Angola" <?php echo e(auth()->guard('webadmin')->user()->country === 'Angola' ? 'selected' : ''); ?>>Angola</option>
                    <option value="Anguilla" <?php echo e(auth()->guard('webadmin')->user()->country === 'Anguilla' ? 'selected' : ''); ?>>Anguilla</option>
                    <option value="Antarctica" <?php echo e(auth()->guard('webadmin')->user()->country === 'Antarctica' ? 'selected' : ''); ?>>Antarctica</option>
                    <option value="Antigua and Barbuda" <?php echo e(auth()->guard('webadmin')->user()->country === 'Antigua and Barbuda' ? 'selected' : ''); ?>>Antigua and Barbuda</option>
                    <option value="Argentina" <?php echo e(auth()->guard('webadmin')->user()->country === 'Argentina' ? 'selected' : ''); ?>>Argentina</option>
                    <option value="Armenia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Armenia' ? 'selected' : ''); ?>>Armenia</option>
                    <option value="Aruba" <?php echo e(auth()->guard('webadmin')->user()->country === 'Aruba' ? 'selected' : ''); ?>>Aruba</option>
                    <option value="Australia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Australia' ? 'selected' : ''); ?>>Australia</option>
                    <option value="Austria" <?php echo e(auth()->guard('webadmin')->user()->country === 'Austria' ? 'selected' : ''); ?>>Austria</option>
                    <option value="Azerbaijan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Azerbaijan' ? 'selected' : ''); ?>>Azerbaijan</option>
                    <option value="Bahamas" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bahamas' ? 'selected' : ''); ?>>Bahamas</option>
                    <option value="Bahrain" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bahrain' ? 'selected' : ''); ?>>Bahrain</option>
                    <option value="Bangladesh" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bangladesh' ? 'selected' : ''); ?>>Bangladesh</option>
                    <option value="Barbados" <?php echo e(auth()->guard('webadmin')->user()->country === 'Barbados' ? 'selected' : ''); ?>>Barbados</option>
                    <option value="Belarus" <?php echo e(auth()->guard('webadmin')->user()->country === 'Belarus' ? 'selected' : ''); ?>>Belarus</option>
                    <option value="Belgium" <?php echo e(auth()->guard('webadmin')->user()->country === 'Belgium' ? 'selected' : ''); ?>>Belgium</option>
                    <option value="Belize" <?php echo e(auth()->guard('webadmin')->user()->country === 'Belize' ? 'selected' : ''); ?>>Belize</option>
                    <option value="Benin" <?php echo e(auth()->guard('webadmin')->user()->country === 'Benin' ? 'selected' : ''); ?>>Benin</option>
                    <option value="Bermuda" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bermuda' ? 'selected' : ''); ?>>Bermuda</option>
                    <option value="Bhutan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bhutan' ? 'selected' : ''); ?>>Bhutan</option>
                    <option value="Bolivia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bolivia' ? 'selected' : ''); ?>>Bolivia</option>
                    <option value="Bosnia and Herzegovina" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bosnia and Herzegovina' ? 'selected' : ''); ?>>Bosnia and Herzegovina</option>
                    <option value="Botswana" <?php echo e(auth()->guard('webadmin')->user()->country === 'Botswana' ? 'selected' : ''); ?>>Botswana</option>
                    <option value="Bouvet Island" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bouvet Island' ? 'selected' : ''); ?>>Bouvet Island</option>
                    <option value="Brazil" <?php echo e(auth()->guard('webadmin')->user()->country === 'Brazil' ? 'selected' : ''); ?>>Brazil</option>
                    <option value="British Indian Ocean Territory" <?php echo e(auth()->guard('webadmin')->user()->country === 'British Indian Ocean Territory' ? 'selected' : ''); ?>>British Indian Ocean Territory</option>
                    <option value="Brunei Darussalam" <?php echo e(auth()->guard('webadmin')->user()->country === 'Brunei Darussalam' ? 'selected' : ''); ?>>Brunei Darussalam</option>
                    <option value="Bulgaria" <?php echo e(auth()->guard('webadmin')->user()->country === 'Bulgaria' ? 'selected' : ''); ?>>Bulgaria</option>
                    <option value="Burkina Faso" <?php echo e(auth()->guard('webadmin')->user()->country === 'Burkina Faso' ? 'selected' : ''); ?>>Burkina Faso</option>
                    <option value="Burundi" <?php echo e(auth()->guard('webadmin')->user()->country === 'Burundi' ? 'selected' : ''); ?>>Burundi</option>
                    <option value="Cambodia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cambodia' ? 'selected' : ''); ?>>Cambodia</option>
                    <option value="Cameroon" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cameroon' ? 'selected' : ''); ?>>Cameroon</option>
                    <option value="Canada" <?php echo e(auth()->guard('webadmin')->user()->country === 'Canada' ? 'selected' : ''); ?>>Canada</option>
                    <option value="Cape Verde" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cape Verde' ? 'selected' : ''); ?>>Cape Verde</option>
                    <option value="Cayman Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cayman Islands' ? 'selected' : ''); ?>>Cayman Islands</option>
                    <option value="Central African Republic" <?php echo e(auth()->guard('webadmin')->user()->country === 'Central African Republic' ? 'selected' : ''); ?>>Central African Republic</option>
                    <option value="Chad" <?php echo e(auth()->guard('webadmin')->user()->country === 'Chad' ? 'selected' : ''); ?>>Chad</option>
                    <option value="Chile" <?php echo e(auth()->guard('webadmin')->user()->country === 'Chile' ? 'selected' : ''); ?>>Chile</option>
                    <option value="China" <?php echo e(auth()->guard('webadmin')->user()->country === 'China' ? 'selected' : ''); ?>>China</option>
                    <option value="Christmas Island" <?php echo e(auth()->guard('webadmin')->user()->country === 'Christmas Island' ? 'selected' : ''); ?>>Christmas Island</option>
                    <option value="Cocos (Keeling) Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cocos (Keeling) Islands' ? 'selected' : ''); ?>>Cocos (Keeling) Islands</option>
                    <option value="Colombia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Colombia' ? 'selected' : ''); ?>>Colombia</option>
                    <option value="Comoros" <?php echo e(auth()->guard('webadmin')->user()->country === 'Comoros' ? 'selected' : ''); ?>>Comoros</option>
                    <option value="Congo" <?php echo e(auth()->guard('webadmin')->user()->country === 'Congo' ? 'selected' : ''); ?>>Congo</option>
                    <option value="Congo, The Democratic Republic of The" <?php echo e(auth()->guard('webadmin')->user()->country === 'Congo, The Democratic Republic of The' ? 'selected' : ''); ?>>Congo, The Democratic Republic of The</option>
                    <option value="Cook Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cook Islands' ? 'selected' : ''); ?>>Cook Islands</option>
                    <option value="Costa Rica" <?php echo e(auth()->guard('webadmin')->user()->country === 'Costa Rica' ? 'selected' : ''); ?>>Costa Rica</option>
                    <option value="Cote D'ivoire" <?php echo e(auth()->guard('webadmin')->user()->country === "Cote D'ivoire" ? 'selected' : ''); ?>>Cote D'ivoire</option>
                    <option value="Croatia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Croatia' ? 'selected' : ''); ?>>Croatia</option>
                    <option value="Cuba" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cuba' ? 'selected' : ''); ?>>Cuba</option>
                    <option value="Cyprus" <?php echo e(auth()->guard('webadmin')->user()->country === 'Cyprus' ? 'selected' : ''); ?>>Cyprus</option>
                    <option value="Czech Republic" <?php echo e(auth()->guard('webadmin')->user()->country === 'Czech Republic' ? 'selected' : ''); ?>>Czech Republic</option>
                    <option value="Denmark" <?php echo e(auth()->guard('webadmin')->user()->country === 'Denmark' ? 'selected' : ''); ?>>Denmark</option>
                    <option value="Djibouti" <?php echo e(auth()->guard('webadmin')->user()->country === 'Djibouti' ? 'selected' : ''); ?>>Djibouti</option>
                    <option value="Dominica" <?php echo e(auth()->guard('webadmin')->user()->country === 'Dominica' ? 'selected' : ''); ?>>Dominica</option>
                    <option value="Dominican Republic" <?php echo e(auth()->guard('webadmin')->user()->country === 'Dominican Republic' ? 'selected' : ''); ?>>Dominican Republic</option>
                    <option value="Ecuador" <?php echo e(auth()->guard('webadmin')->user()->country === 'Ecuador' ? 'selected' : ''); ?>>Ecuador</option>
                    <option value="Egypt" <?php echo e(auth()->guard('webadmin')->user()->country === 'Egypt' ? 'selected' : ''); ?>>Egypt</option>
                    <option value="El Salvador" <?php echo e(auth()->guard('webadmin')->user()->country === 'El Salvador' ? 'selected' : ''); ?>>El Salvador</option>
                    <option value="Equatorial Guinea" <?php echo e(auth()->guard('webadmin')->user()->country === 'Equatorial Guinea' ? 'selected' : ''); ?>>Equatorial Guinea</option>
                    <option value="Eritrea" <?php echo e(auth()->guard('webadmin')->user()->country === 'Eritrea' ? 'selected' : ''); ?>>Eritrea</option>
                    <option value="Estonia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Estonia' ? 'selected' : ''); ?>>Estonia</option>
                    <option value="Ethiopia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Ethiopia' ? 'selected' : ''); ?>>Ethiopia</option>
                    <option value="Falkland Islands (Malvinas)" <?php echo e(auth()->guard('webadmin')->user()->country === 'Falkland Islands (Malvinas)' ? 'selected' : ''); ?>>Falkland Islands (Malvinas)</option>
                    <option value="Faroe Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Faroe Islands' ? 'selected' : ''); ?>>Faroe Islands</option>
                    <option value="Fiji" <?php echo e(auth()->guard('webadmin')->user()->country === 'Fiji' ? 'selected' : ''); ?>>Fiji</option>
                    <option value="Finland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Finland' ? 'selected' : ''); ?>>Finland</option>
                    <option value="France" <?php echo e(auth()->guard('webadmin')->user()->country === 'France' ? 'selected' : ''); ?>>France</option>
                    <option value="French Guiana" <?php echo e(auth()->guard('webadmin')->user()->country === 'French Guiana' ? 'selected' : ''); ?>>French Guiana</option>
                    <option value="French Polynesia" <?php echo e(auth()->guard('webadmin')->user()->country === 'French Polynesia' ? 'selected' : ''); ?>>French Polynesia</option>
                    <option value="French Southern Territories" <?php echo e(auth()->guard('webadmin')->user()->country === 'French Southern Territories' ? 'selected' : ''); ?>>French Southern Territories</option>
                    <option value="Gabon" <?php echo e(auth()->guard('webadmin')->user()->country === 'Gabon' ? 'selected' : ''); ?>>Gabon</option>
                    <option value="Gambia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Gambia' ? 'selected' : ''); ?>>Gambia</option>
                    <option value="Georgia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Georgia' ? 'selected' : ''); ?>>Georgia</option>
                    <option value="Germany" <?php echo e(auth()->guard('webadmin')->user()->country === 'Germany' ? 'selected' : ''); ?>>Germany</option>
                    <option value="Ghana" <?php echo e(auth()->guard('webadmin')->user()->country === 'Ghana' ? 'selected' : ''); ?>>Ghana</option>
                    <option value="Gibraltar" <?php echo e(auth()->guard('webadmin')->user()->country === 'Gibraltar' ? 'selected' : ''); ?>>Gibraltar</option>
                    <option value="Greece" <?php echo e(auth()->guard('webadmin')->user()->country === 'Greece' ? 'selected' : ''); ?>>Greece</option>
                    <option value="Greenland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Greenland' ? 'selected' : ''); ?>>Greenland</option>
                    <option value="Grenada" <?php echo e(auth()->guard('webadmin')->user()->country === 'Grenada' ? 'selected' : ''); ?>>Grenada</option>
                    <option value="Guadeloupe" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guadeloupe' ? 'selected' : ''); ?>>Guadeloupe</option>
                    <option value="Guam" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guam' ? 'selected' : ''); ?>>Guam</option>
                    <option value="Guatemala" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guatemala' ? 'selected' : ''); ?>>Guatemala</option>
                    <option value="Guernsey" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guernsey' ? 'selected' : ''); ?>>Guernsey</option>
                    <option value="Guinea" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guinea' ? 'selected' : ''); ?>>Guinea</option>
                    <option value="Guinea-bissau" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guinea-bissau' ? 'selected' : ''); ?>>Guinea-bissau</option>
                    <option value="Guyana" <?php echo e(auth()->guard('webadmin')->user()->country === 'Guyana' ? 'selected' : ''); ?>>Guyana</option>
                    <option value="Haiti" <?php echo e(auth()->guard('webadmin')->user()->country === 'Haiti' ? 'selected' : ''); ?>>Haiti</option>
                    <option value="Heard Island and Mcdonald Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Heard Island and Mcdonald Islands' ? 'selected' : ''); ?>>Heard Island and Mcdonald Islands</option>
                    <option value="Holy See (Vatican City State)" <?php echo e(auth()->guard('webadmin')->user()->country === 'Holy See (Vatican City State)' ? 'selected' : ''); ?>>Holy See (Vatican City State)</option>
                    <option value="Honduras" <?php echo e(auth()->guard('webadmin')->user()->country === 'Honduras' ? 'selected' : ''); ?>>Honduras</option>
                    <option value="Hong Kong" <?php echo e(auth()->guard('webadmin')->user()->country === 'Hong Kong' ? 'selected' : ''); ?>>Hong Kong</option>
                    <option value="Hungary" <?php echo e(auth()->guard('webadmin')->user()->country === 'Hungary' ? 'selected' : ''); ?>>Hungary</option>
                    <option value="Iceland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Iceland' ? 'selected' : ''); ?>>Iceland</option>
                    <option value="India" <?php echo e(auth()->guard('webadmin')->user()->country === 'India' ? 'selected' : ''); ?>>India</option>
                    <option value="Indonesia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Indonesia' ? 'selected' : ''); ?>>Indonesia</option>
                    <option value="Iran, Islamic Republic of" <?php echo e(auth()->guard('webadmin')->user()->country === 'Iran, Islamic Republic of' ? 'selected' : ''); ?>>Iran, Islamic Republic of</option>
                    <option value="Iraq" <?php echo e(auth()->guard('webadmin')->user()->country === 'Iraq' ? 'selected' : ''); ?>>Iraq</option>
                    <option value="Ireland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Ireland' ? 'selected' : ''); ?>>Ireland</option>
                    <option value="Isle of Man" <?php echo e(auth()->guard('webadmin')->user()->country === 'Isle of Man' ? 'selected' : ''); ?>>Isle of Man</option>
                    <option value="Israel" <?php echo e(auth()->guard('webadmin')->user()->country === 'Israel' ? 'selected' : ''); ?>>Israel</option>
                    <option value="Italy" <?php echo e(auth()->guard('webadmin')->user()->country === 'Italy' ? 'selected' : ''); ?>>Italy</option>
                    <option value="Jamaica" <?php echo e(auth()->guard('webadmin')->user()->country === 'Jamaica' ? 'selected' : ''); ?>>Jamaica</option>
                    <option value="Japan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Japan' ? 'selected' : ''); ?>>Japan</option>
                    <option value="Jersey" <?php echo e(auth()->guard('webadmin')->user()->country === 'Jersey' ? 'selected' : ''); ?>>Jersey</option>
                    <option value="Jordan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Jordan' ? 'selected' : ''); ?>>Jordan</option>
                    <option value="Kazakhstan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Kazakhstan' ? 'selected' : ''); ?>>Kazakhstan</option>
                    <option value="Kenya" <?php echo e(auth()->guard('webadmin')->user()->country === 'Kenya' ? 'selected' : ''); ?>>Kenya</option>
                    <option value="Kiribati" <?php echo e(auth()->guard('webadmin')->user()->country === 'Kiribati' ? 'selected' : ''); ?>>Kiribati</option>
                    <option value="Korea, Democratic People's Republic of" <?php echo e(auth()->guard('webadmin')->user()->country === "Korea, Democratic People's Republic of" ? 'selected' : ''); ?>>Korea, Democratic People's Republic of</option>
                    <option value="Korea, Republic of" <?php echo e(auth()->guard('webadmin')->user()->country === 'Korea, Republic of' ? 'selected' : ''); ?>>Korea, Republic of</option>
                    <option value="Kuwait" <?php echo e(auth()->guard('webadmin')->user()->country === 'Kuwait' ? 'selected' : ''); ?>>Kuwait</option>
                    <option value="Kyrgyzstan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Kyrgyzstan' ? 'selected' : ''); ?>>Kyrgyzstan</option>
                    <option value="Lao People's Democratic Republic" <?php echo e(auth()->guard('webadmin')->user()->country === "Lao People's Democratic Republic" ? 'selected' : ''); ?>>Lao People's Democratic Republic</option>
                    <option value="Latvia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Latvia' ? 'selected' : ''); ?>>Latvia</option>
                    <option value="Lebanon" <?php echo e(auth()->guard('webadmin')->user()->country === 'Lebanon' ? 'selected' : ''); ?>>Lebanon</option>
                    <option value="Lesotho" <?php echo e(auth()->guard('webadmin')->user()->country === 'Lesotho' ? 'selected' : ''); ?>>Lesotho</option>
                    <option value="Liberia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Liberia' ? 'selected' : ''); ?>>Liberia</option>
                    <option value="Libyan Arab Jamahiriya" <?php echo e(auth()->guard('webadmin')->user()->country === 'Libyan Arab Jamahiriya' ? 'selected' : ''); ?>>Libyan Arab Jamahiriya</option>
                    <option value="Liechtenstein" <?php echo e(auth()->guard('webadmin')->user()->country === 'Liechtenstein' ? 'selected' : ''); ?>>Liechtenstein</option>
                    <option value="Lithuania" <?php echo e(auth()->guard('webadmin')->user()->country === 'Lithuania' ? 'selected' : ''); ?>>Lithuania</option>
                    <option value="Luxembourg" <?php echo e(auth()->guard('webadmin')->user()->country === 'Luxembourg' ? 'selected' : ''); ?>>Luxembourg</option>
                    <option value="Macao" <?php echo e(auth()->guard('webadmin')->user()->country === 'Macao' ? 'selected' : ''); ?>>Macao</option>
                    <option value="Macedonia, The Former Yugoslav Republic of" <?php echo e(auth()->guard('webadmin')->user()->country === 'Macedonia, The Former Yugoslav Republic of' ? 'selected' : ''); ?>>Macedonia, The Former Yugoslav Republic of</option>
                    <option value="Madagascar" <?php echo e(auth()->guard('webadmin')->user()->country === 'Madagascar' ? 'selected' : ''); ?>>Madagascar</option>
                    <option value="Malawi" <?php echo e(auth()->guard('webadmin')->user()->country === 'Malawi' ? 'selected' : ''); ?>>Malawi</option>
                    <option value="Malaysia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Malaysia' ? 'selected' : ''); ?>>Malaysia</option>
                    <option value="Maldives" <?php echo e(auth()->guard('webadmin')->user()->country === 'Maldives' ? 'selected' : ''); ?>>Maldives</option>
                    <option value="Mali" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mali' ? 'selected' : ''); ?>>Mali</option>
                    <option value="Malta" <?php echo e(auth()->guard('webadmin')->user()->country === 'Malta' ? 'selected' : ''); ?>>Malta</option>
                    <option value="Marshall Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Marshall Islands' ? 'selected' : ''); ?>>Marshall Islands</option>
                    <option value="Martinique" <?php echo e(auth()->guard('webadmin')->user()->country === 'Martinique' ? 'selected' : ''); ?>>Martinique</option>
                    <option value="Mauritania" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mauritania' ? 'selected' : ''); ?>>Mauritania</option>
                    <option value="Mauritius" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mauritius' ? 'selected' : ''); ?>>Mauritius</option>
                    <option value="Mayotte" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mayotte' ? 'selected' : ''); ?>>Mayotte</option>
                    <option value="Mexico" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mexico' ? 'selected' : ''); ?>>Mexico</option>
                    <option value="Micronesia, Federated States of" <?php echo e(auth()->guard('webadmin')->user()->country === 'Micronesia, Federated States of' ? 'selected' : ''); ?>>Micronesia, Federated States of</option>
                    <option value="Moldova, Republic of" <?php echo e(auth()->guard('webadmin')->user()->country === 'Moldova, Republic of' ? 'selected' : ''); ?>>Moldova, Republic of</option>
                    <option value="Monaco" <?php echo e(auth()->guard('webadmin')->user()->country === 'Monaco' ? 'selected' : ''); ?>>Monaco</option>
                    <option value="Mongolia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mongolia' ? 'selected' : ''); ?>>Mongolia</option>
                    <option value="Montenegro" <?php echo e(auth()->guard('webadmin')->user()->country === 'Montenegro' ? 'selected' : ''); ?>>Montenegro</option>
                    <option value="Montserrat" <?php echo e(auth()->guard('webadmin')->user()->country === 'Montserrat' ? 'selected' : ''); ?>>Montserrat</option>
                    <option value="Morocco" <?php echo e(auth()->guard('webadmin')->user()->country === 'Morocco' ? 'selected' : ''); ?>>Morocco</option>
                    <option value="Mozambique" <?php echo e(auth()->guard('webadmin')->user()->country === 'Mozambique' ? 'selected' : ''); ?>>Mozambique</option>
                    <option value="Myanmar" <?php echo e(auth()->guard('webadmin')->user()->country === 'Myanmar' ? 'selected' : ''); ?>>Myanmar</option>
                    <option value="Namibia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Namibia' ? 'selected' : ''); ?>>Namibia</option>
                    <option value="Nauru" <?php echo e(auth()->guard('webadmin')->user()->country === 'Nauru' ? 'selected' : ''); ?>>Nauru</option>
                    <option value="Nepal" <?php echo e(auth()->guard('webadmin')->user()->country === 'Nepal' ? 'selected' : ''); ?>>Nepal</option>
                    <option value="Netherlands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Netherlands' ? 'selected' : ''); ?>>Netherlands</option>
                    <option value="Netherlands Antilles" <?php echo e(auth()->guard('webadmin')->user()->country === 'Netherlands Antilles' ? 'selected' : ''); ?>>Netherlands Antilles</option>
                    <option value="New Caledonia" <?php echo e(auth()->guard('webadmin')->user()->country === 'New Caledonia' ? 'selected' : ''); ?>>New Caledonia</option>
                    <option value="New Zealand" <?php echo e(auth()->guard('webadmin')->user()->country === 'New Zealand' ? 'selected' : ''); ?>>New Zealand</option>
                    <option value="Nicaragua" <?php echo e(auth()->guard('webadmin')->user()->country === 'Nicaragua' ? 'selected' : ''); ?>>Nicaragua</option>
                    <option value="Niger" <?php echo e(auth()->guard('webadmin')->user()->country === 'Niger' ? 'selected' : ''); ?>>Niger</option>
                    <option value="Nigeria" <?php echo e(auth()->guard('webadmin')->user()->country === 'Nigeria' ? 'selected' : ''); ?>>Nigeria</option>
                    <option value="Niue" <?php echo e(auth()->guard('webadmin')->user()->country === 'Niue' ? 'selected' : ''); ?>>Niue</option>
                    <option value="Norfolk Island" <?php echo e(auth()->guard('webadmin')->user()->country === 'Norfolk Island' ? 'selected' : ''); ?>>Norfolk Island</option>
                    <option value="Northern Mariana Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Northern Mariana Islands' ? 'selected' : ''); ?>>Northern Mariana Islands</option>
                    <option value="Norway" <?php echo e(auth()->guard('webadmin')->user()->country === 'Norway' ? 'selected' : ''); ?>>Norway</option>
                    <option value="Oman" <?php echo e(auth()->guard('webadmin')->user()->country === 'Oman' ? 'selected' : ''); ?>>Oman</option>
                    <option value="Pakistan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Pakistan' ? 'selected' : ''); ?>>Pakistan</option>
                    <option value="Palau" <?php echo e(auth()->guard('webadmin')->user()->country === 'Palau' ? 'selected' : ''); ?>>Palau</option>
                    <option value="Palestinian Territory, Occupied" <?php echo e(auth()->guard('webadmin')->user()->country === 'Palestinian Territory, Occupied' ? 'selected' : ''); ?>>Palestinian Territory, Occupied</option>
                    <option value="Panama" <?php echo e(auth()->guard('webadmin')->user()->country === 'Panama' ? 'selected' : ''); ?>>Panama</option>
                    <option value="Papua New Guinea" <?php echo e(auth()->guard('webadmin')->user()->country === 'Papua New Guinea' ? 'selected' : ''); ?>>Papua New Guinea</option>
                    <option value="Paraguay" <?php echo e(auth()->guard('webadmin')->user()->country === 'Paraguay' ? 'selected' : ''); ?>>Paraguay</option>
                    <option value="Peru" <?php echo e(auth()->guard('webadmin')->user()->country === 'Peru' ? 'selected' : ''); ?>>Peru</option>
                    <option value="Philippines" <?php echo e(auth()->guard('webadmin')->user()->country === 'Philippines' ? 'selected' : ''); ?>>Philippines</option>
                    <option value="Pitcairn" <?php echo e(auth()->guard('webadmin')->user()->country === 'Pitcairn' ? 'selected' : ''); ?>>Pitcairn</option>
                    <option value="Poland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Poland' ? 'selected' : ''); ?>>Poland</option>
                    <option value="Portugal" <?php echo e(auth()->guard('webadmin')->user()->country === 'Portugal' ? 'selected' : ''); ?>>Portugal</option>
                    <option value="Puerto Rico" <?php echo e(auth()->guard('webadmin')->user()->country === 'Puerto Rico' ? 'selected' : ''); ?>>Puerto Rico</option>
                    <option value="Qatar" <?php echo e(auth()->guard('webadmin')->user()->country === 'Qatar' ? 'selected' : ''); ?>>Qatar</option>
                    <option value="Reunion" <?php echo e(auth()->guard('webadmin')->user()->country === 'Reunion' ? 'selected' : ''); ?>>Reunion</option>
                    <option value="Romania" <?php echo e(auth()->guard('webadmin')->user()->country === 'Romania' ? 'selected' : ''); ?>>Romania</option>
                    <option value="Russian Federation" <?php echo e(auth()->guard('webadmin')->user()->country === 'Russian Federation' ? 'selected' : ''); ?>>Russian Federation</option>
                    <option value="Rwanda" <?php echo e(auth()->guard('webadmin')->user()->country === 'Rwanda' ? 'selected' : ''); ?>>Rwanda</option>
                    <option value="Saint Helena" <?php echo e(auth()->guard('webadmin')->user()->country === 'Saint Helena' ? 'selected' : ''); ?>>Saint Helena</option>
                    <option value="Saint Kitts and Nevis" <?php echo e(auth()->guard('webadmin')->user()->country === 'Saint Kitts and Nevis' ? 'selected' : ''); ?>>Saint Kitts and Nevis</option>
                    <option value="Saint Lucia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Saint Lucia' ? 'selected' : ''); ?>>Saint Lucia</option>
                    <option value="Saint Pierre and Miquelon" <?php echo e(auth()->guard('webadmin')->user()->country === 'Saint Pierre and Miquelon' ? 'selected' : ''); ?>>Saint Pierre and Miquelon</option>
                    <option value="Saint Vincent and The Grenadines" <?php echo e(auth()->guard('webadmin')->user()->country === 'Saint Vincent and The Grenadines' ? 'selected' : ''); ?>>Saint Vincent and The Grenadines</option>
                    <option value="Samoa" <?php echo e(auth()->guard('webadmin')->user()->country === 'Samoa' ? 'selected' : ''); ?>>Samoa</option>
                    <option value="San Marino" <?php echo e(auth()->guard('webadmin')->user()->country === 'San Marino' ? 'selected' : ''); ?>>San Marino</option>
                    <option value="Sao Tome and Principe" <?php echo e(auth()->guard('webadmin')->user()->country === 'Sao Tome and Principe' ? 'selected' : ''); ?>>Sao Tome and Principe</option>
                    <option value="Saudi Arabia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Saudi Arabia' ? 'selected' : ''); ?>>Saudi Arabia</option>
                    <option value="Senegal" <?php echo e(auth()->guard('webadmin')->user()->country === 'Senegal' ? 'selected' : ''); ?>>Senegal</option>
                    <option value="Serbia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Serbia' ? 'selected' : ''); ?>>Serbia</option>
                    <option value="Seychelles" <?php echo e(auth()->guard('webadmin')->user()->country === 'Seychelles' ? 'selected' : ''); ?>>Seychelles</option>
                    <option value="Sierra Leone" <?php echo e(auth()->guard('webadmin')->user()->country === 'Sierra Leone' ? 'selected' : ''); ?>>Sierra Leone</option>
                    <option value="Singapore" <?php echo e(auth()->guard('webadmin')->user()->country === 'Singapore' ? 'selected' : ''); ?>>Singapore</option>
                    <option value="Slovakia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Slovakia' ? 'selected' : ''); ?>>Slovakia</option>
                    <option value="Slovenia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Slovenia' ? 'selected' : ''); ?>>Slovenia</option>
                    <option value="Solomon Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Solomon Islands' ? 'selected' : ''); ?>>Solomon Islands</option>
                    <option value="Somalia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Somalia' ? 'selected' : ''); ?>>Somalia</option>
                    <option value="South Africa" <?php echo e(auth()->guard('webadmin')->user()->country === 'South Africa' ? 'selected' : ''); ?>>South Africa</option>
                    <option value="South Georgia and The South Sandwich Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'South Georgia and The South Sandwich Islands' ? 'selected' : ''); ?>>South Georgia and The South Sandwich Islands</option>
                    <option value="Spain" <?php echo e(auth()->guard('webadmin')->user()->country === 'Spain' ? 'selected' : ''); ?>>Spain</option>
                    <option value="Sri Lanka" <?php echo e(auth()->guard('webadmin')->user()->country === 'Sri Lanka' ? 'selected' : ''); ?>>Sri Lanka</option>
                    <option value="Sudan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Sudan' ? 'selected' : ''); ?>>Sudan</option>
                    <option value="Suriname" <?php echo e(auth()->guard('webadmin')->user()->country === 'Suriname' ? 'selected' : ''); ?>>Suriname</option>
                    <option value="Svalbard and Jan Mayen" <?php echo e(auth()->guard('webadmin')->user()->country === 'Svalbard and Jan Mayen' ? 'selected' : ''); ?>>Svalbard and Jan Mayen</option>
                    <option value="Swaziland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Swaziland' ? 'selected' : ''); ?>>Swaziland</option>
                    <option value="Sweden" <?php echo e(auth()->guard('webadmin')->user()->country === 'Sweden' ? 'selected' : ''); ?>>Sweden</option>
                    <option value="Switzerland" <?php echo e(auth()->guard('webadmin')->user()->country === 'Switzerland' ? 'selected' : ''); ?>>Switzerland</option>
                    <option value="Syrian Arab Republic" <?php echo e(auth()->guard('webadmin')->user()->country === 'Syrian Arab Republic' ? 'selected' : ''); ?>>Syrian Arab Republic</option>
                    <option value="Taiwan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Taiwan' ? 'selected' : ''); ?>>Taiwan</option>
                    <option value="Tajikistan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Tajikistan' ? 'selected' : ''); ?>>Tajikistan</option>
                    <option value="Tanzania, United Republic of" <?php echo e(auth()->guard('webadmin')->user()->country === 'Tanzania, United Republic of' ? 'selected' : ''); ?>>Tanzania, United Republic of</option>
                    <option value="Thailand" <?php echo e(auth()->guard('webadmin')->user()->country === 'Thailand' ? 'selected' : ''); ?>>Thailand</option>
                    <option value="Timor-leste" <?php echo e(auth()->guard('webadmin')->user()->country === 'Timor-leste' ? 'selected' : ''); ?>>Timor-leste</option>
                    <option value="Togo" <?php echo e(auth()->guard('webadmin')->user()->country === 'Togo' ? 'selected' : ''); ?>>Togo</option>
                    <option value="Tokelau" <?php echo e(auth()->guard('webadmin')->user()->country === 'Tokelau' ? 'selected' : ''); ?>>Tokelau</option>
                    <option value="Tonga" <?php echo e(auth()->guard('webadmin')->user()->country === 'Tonga' ? 'selected' : ''); ?>>Tonga</option>
                    <option value="Trinidad and Tobago" <?php echo e(auth()->guard('webadmin')->user()->country === 'Trinidad and Tobago' ? 'selected' : ''); ?>>Trinidad and Tobago</option>
                    <option value="Tunisia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Tunisia' ? 'selected' : ''); ?>>Tunisia</option>
                    <option value="Turkey" <?php echo e(auth()->guard('webadmin')->user()->country === 'Turkey' ? 'selected' : ''); ?>>Turkey</option>
                    <option value="Turkmenistan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Turkmenistan' ? 'selected' : ''); ?>>Turkmenistan</option>
                    <option value="Turks and Caicos Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'Turks and Caicos Islands' ? 'selected' : ''); ?>>Turks and Caicos Islands</option>
                    <option value="Tuvalu" <?php echo e(auth()->guard('webadmin')->user()->country === 'Tuvalu' ? 'selected' : ''); ?>>Tuvalu</option>
                    <option value="Uganda" <?php echo e(auth()->guard('webadmin')->user()->country === 'Uganda' ? 'selected' : ''); ?>>Uganda</option>
                    <option value="Ukraine" <?php echo e(auth()->guard('webadmin')->user()->country === 'Ukraine' ? 'selected' : ''); ?>>Ukraine</option>
                    <option value="United Arab Emirates" <?php echo e(auth()->guard('webadmin')->user()->country === 'United Arab Emirates' ? 'selected' : ''); ?>>United Arab Emirates</option>
                    <option value="United Kingdom" <?php echo e(auth()->guard('webadmin')->user()->country === 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom</option>
                    <option value="United States" <?php echo e(auth()->guard('webadmin')->user()->country === 'United States' ? 'selected' : ''); ?>>United States</option>
                    <option value="United States Minor Outlying Islands" <?php echo e(auth()->guard('webadmin')->user()->country === 'United States Minor Outlying Islands' ? 'selected' : ''); ?>>United States Minor Outlying Islands</option>
                    <option value="Uruguay" <?php echo e(auth()->guard('webadmin')->user()->country === 'Uruguay' ? 'selected' : ''); ?>>Uruguay</option>
                    <option value="Uzbekistan" <?php echo e(auth()->guard('webadmin')->user()->country === 'Uzbekistan' ? 'selected' : ''); ?>>Uzbekistan</option>
                    <option value="Vanuatu" <?php echo e(auth()->guard('webadmin')->user()->country === 'Vanuatu' ? 'selected' : ''); ?>>Vanuatu</option>
                    <option value="Venezuela" <?php echo e(auth()->guard('webadmin')->user()->country === 'Venezuela' ? 'selected' : ''); ?>>Venezuela</option>
                    <option value="Viet Nam" <?php echo e(auth()->guard('webadmin')->user()->country === 'Viet Nam' ? 'selected' : ''); ?>>Viet Nam</option>
                    <option value="Virgin Islands, British" <?php echo e(auth()->guard('webadmin')->user()->country === 'Virgin Islands, British' ? 'selected' : ''); ?>>Virgin Islands, British</option>
                    <option value="Virgin Islands, U.S." <?php echo e(auth()->guard('webadmin')->user()->country === 'Virgin Islands, U.S.' ? 'selected' : ''); ?>>Virgin Islands, U.S.</option>
                    <option value="Wallis and Futuna" <?php echo e(auth()->guard('webadmin')->user()->country === 'Wallis and Futuna' ? 'selected' : ''); ?>>Wallis and Futuna</option>
                    <option value="Western Sahara" <?php echo e(auth()->guard('webadmin')->user()->country === 'Western Sahara' ? 'selected' : ''); ?>>Western Sahara</option>
                    <option value="Yemen" <?php echo e(auth()->guard('webadmin')->user()->country === 'Yemen' ? 'selected' : ''); ?>>Yemen</option>
                    <option value="Zambia" <?php echo e(auth()->guard('webadmin')->user()->country === 'Zambia' ? 'selected' : ''); ?>>Zambia</option>
                    <option value="Zimbabwe" <?php echo e(auth()->guard('webadmin')->user()->country === 'Zimbabwe' ? 'selected' : ''); ?>>Zimbabwe</option>

                  </select>
                </div>
                <div class="form-group">
                    <label for="address">Residential Address</label>
                    <input type="text" class="form-control" name="address" id="address" value="<?php echo e(auth()->guard('webadmin')->user()->address); ?>">
                </div>
                <br><br>
                <div class="form-group">
                    <label for="address"><h4><b>Occupation Details</b></h4></label>
                </div>
                <div class="form-group">
                    <label for="sector">Sector</label>
                    <select class="form-control" name="sector" id="sector" value="<?php echo e(auth()->guard('webadmin')->user()->sector); ?>">
                        <option value="" disabled selected>Select Sector</option>
                        <option value="public" <?php echo e(auth()->guard('webadmin')->user()->sector === 'public' ? 'selected' : ''); ?>>Public</option>
                        <option value="private" <?php echo e(auth()->guard('webadmin')->user()->sector === 'privete' ? 'selected' : ''); ?>>Private</option>
                        <option value="own" <?php echo e(auth()->guard('webadmin')->user()->sector === 'own' ? 'selected' : ''); ?>>Own Business</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="designation">Designation</label>
                    <input type="text" class="form-control" name="designation" id="designation" value="<?php echo e(auth()->guard('webadmin')->user()->designation); ?>">
                </div>
                <style>
                    .custom-button {
                        background-color: #211046; /* Dark purple color */
                        color: #ffffff; /* White text color */
                        border: none;
                        padding: 10px 20px;
                        cursor: pointer;
                        border-radius: 4px;
                        transition: background-color 0.3s ease;
                    }

                    .custom-button:hover {
                        background-color: #007bff; /* Blue color on hover */
                    }
                </style>
                <div class="text-center"><button type="submit" class="custom-button">Submit</button></div>
              </form>
            </div>

          </div>

        </div>
      </section>  -->



  </main><!-- End #main -->

    <script>
        function previewImage(event) {
            var input = event.target;
            var preview = document.getElementById('imagePreview');

            // Check if a file is selected
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    preview.innerHTML = '<img src="' + e.target.result + '" alt="Preview">';
                };

                reader.readAsDataURL(input.files[0]);
            } else {
                preview.innerHTML = '';
            }
        }
    </script>
<script>
  function showLogoutModal() {
      // Show the modal
      $('#staticBackdrop').modal('show');
  }

  function logout() {
      // Correctly target the logout form by ID and submit it
      var logoutForm = document.getElementById('logoutForm');
      if (logoutForm) {
          logoutForm.action = '<?php echo e(route('logout')); ?>'; // Ensure this line is directly in the Blade file
          logoutForm.submit();
      } else {
          console.error('Logout form not found');
      }
  }
</script>


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('vendor/purecounter/purecounter_vanilla.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/typed.js/typed.umd.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/waypoints/noframework.waypoints.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/php-email-form/validate.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('js/user.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\Github\uor_alumni_project\Alumni-FOS\resources\views/template/admin.blade.php ENDPATH**/ ?>