<!DOCTYPE html>
<html>
<head>
    <title>Alumni-FOS Register Acceptence</title>
</head>

<body>

    <p style="font-size: 12px">
        Dear {{ $user }},<br>
        You have successfully registered to the Alumni-FOS.<br>
        Thank you. Best Regards!
    </p><br>

    <p><?php echo "Please Don't reply to this email"; ?></p>

</body>

</html>